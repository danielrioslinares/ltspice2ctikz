
from PIL import Image
from time import sleep
import os,sys

import matplotlib.pyplot as plt

from datetime import datetime
import configparser
import subprocess

print( "==================================================" )
print( "LTSPICE2CTIKZ WATCHDOG                       v1.02" )
print( "                    august 1, 2021 - july 10, 2022" )
print( "                               Daniel Rios Linares" )
print( "                                    riv@hotmail.es" )
print( "==================================================" )

# Check if the application is a frozen exe or not
if getattr(sys, 'frozen', False):
    application_path = os.path.dirname( sys.executable )
elif __file__:
    application_path = os.path.dirname( __file__ )

# Get the file path to be inspected
file_path = sys.argv[1:][0]
dir_name,file_name = os.path.split( file_path )
file_time = None

# Configuration file
config_file = os.path.join(application_path, "config.ini")
config = configparser.ConfigParser()
config.read_file( open( config_file, 'r', encoding='utf-8' ) )

# Application settings
TEMPORAL_FOLDER = config.get( 'Application', 'TEMPORAL_FOLDER' )
CMD = ".\ltspice2ctikz v1.02.exe {}".format( file_path )

# Temporal files deletion
print( " -> Deleting old temporal files..." )
for tmp_file in [ "tmp.pdf", "tmp.svg", "tmp.png", "tmp.tex" ]:
	try: os.remove( os.path.join( TEMPORAL_FOLDER, tmp_file ) )
	except: pass

# Detect file
print( " -> File {}...".format( file_path ) )
if os.path.isfile( file_path ):
	print( "  | -> Schematic found!" )
else:
	print( "  |  | * FATAL ERROR: schematic not found!")
	sys.exit(-1)

# Create the figure
plt.ion()
fig = plt.figure()
ax = fig.add_subplot(111)
fig.canvas.mpl_connect( 'close_event', lambda *args : sys.exit(0) )
plt.axis( 'off' )

# Plot a black square for now
img_plot = plt.imshow( Image.new('RGB', (100, 100) ), aspect = 'auto' )

# Forever loop
while True:
	# Record the last modified time
	file_time_new = os.path.getmtime( file_path )

	# If it differs...
	if file_time != file_time_new:

		# 1) Compile it!
		subprocess.call( CMD, stdout = subprocess.DEVNULL )

		# 2) Convert svg to png for display
		png_path = os.path.join(TEMPORAL_FOLDER, "tmp.png")

		# 3) Plot it!
		png_img = Image.open( png_path )
		img_plot.set( data = png_img )
		file_time = file_time_new

		# 4) Resize
		png_w, png_h = png_img.size
		fig_w = fig.get_figwidth()
		fig.set_figheight( png_h / png_w * fig_w )

		# 5) Tell about the new render
		message = datetime.fromtimestamp( file_time ).strftime('%Y/%m/%d-%H:%M:%S')
		ax.set_title( message )
		print( "  |  | * New instance {}".format( message ))

	fig.canvas.draw()
	fig.canvas.flush_events()


#
