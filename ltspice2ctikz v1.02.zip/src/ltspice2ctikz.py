
import ltspice2ctikz as l2c

from cairosvg import svg2png

import sys, os, shutil
import subprocess
import time

import configparser

print( "==================================================" )
print( "LTSPICE2CTIKZ                                v1.02" )
print( "                    august 1, 2021 - july 10, 2022" )
print( "                               Daniel Rios Linares" )
print( "                                    riv@hotmail.es" )
print( "==================================================" )

# Check if the application is a frozen exe or not
if getattr(sys, 'frozen', False):
    application_path = os.path.dirname( sys.executable )
elif __file__:
    application_path = os.path.dirname( __file__ )

# Configuration file
config_file = os.path.join(application_path, "config.ini")
config = configparser.ConfigParser()
config.read_file( open( config_file, 'r', encoding='utf-8' ) )

# Application settings
TEMPORAL_FOLDER = config.get( 'Application', 'TEMPORAL_FOLDER' )
PDF2SVG = config.get( 'Application', 'PDF2SVG' )
PDFLATEX = config.get( 'Application', 'PDFLATEX' )
SYM_LIB = config.get( 'Application', 'SYM_LIB' )

# Input files
for f_input in sys.argv[1:]:
	print( " -> File {}...".format( f_input ) )
	if os.path.isfile( f_input ):
		print( "  | -> Schematic found!" )
	else:
		print( "  |  | * FATAL ERROR: schematic not found!")
		sys.exit(-1)

	# Get schematic
	s = l2c.Asc( f_input, sym_lib = SYM_LIB )
	s.ctikzset.append( config.get( 'Circuitikz', 'voltages' ) + " voltages" )
	s.ctikzset.append( config.get( 'Circuitikz', 'currents' ) + " currents" )
	s.ctikzset.append( config.get( 'Circuitikz', 'resistors' ) + " resistors" )
	s.ctikzset.append( config.get( 'Circuitikz', 'inductors' ) + " inductors" )
	s.tikzpicture.append( "line width = " + config.get( 'Circuitikz', 'line width' ) )

	# Convert to tex code
	tex = s.__repr__()
	print( "  |  | * Schematic converted to TeX code" )

	print( "  |  | * Deleting old temporal files..." )
	for tmp_file in [ "tmp.pdf", "tmp.svg", "tmp.png", "tmp.tex" ]:
		try: os.remove( os.path.join( TEMPORAL_FOLDER, tmp_file ) )
		except: pass

	# Run the TeX code in the temporal folder
	tex_tmp = os.path.join( TEMPORAL_FOLDER, "tmp.tex" )
	tex_out = os.path.join( f_input[:-3] + "tex" )
	print( tex, file = open( tex_tmp, 'w' ) )
	print( "  | -> TeX code written to temporal folder!" )
	subprocess.call( "{} {} -output-directory=\"{}\"".format( PDFLATEX, tex_tmp, TEMPORAL_FOLDER ), stdout=subprocess.DEVNULL )
	print( "  | -> PDF written to temporal folder!" )
	pdf_tmp = os.path.join( TEMPORAL_FOLDER, "tmp.pdf" )
	pdf_out = os.path.join( f_input[:-3] + "pdf" )
	svg_tmp = os.path.join( TEMPORAL_FOLDER, "tmp.svg" )
	svg_out = os.path.join( f_input[:-3] + "svg" )
	subprocess.call( "{} {} {}".format( PDF2SVG, pdf_tmp, svg_tmp ), stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE ) #, stdout=subprocess.DEVNULL )
	print( "  |  | * PDF converted to SVG" )
	png_tmp = os.path.join(TEMPORAL_FOLDER, "tmp.png")
	png_out = os.path.join( f_input[:-3] + "png" )
	svg2png( url = svg_tmp, write_to = png_tmp, scale = 6 )
	print( "  |  | * SVG converted to PNG" )

	# Config file
	cfg_tmp = config_file
	cfg_out = os.path.join( f_input[:-3] + "ini" )

	# Move the .tex, .pdf and .svg to the output folder
	if config.get( 'Output', 'tex' ) == "true":
		shutil.copy( tex_tmp, tex_out )
		print( "  |  | * TeX written to output folder!" )

	if config.get( 'Output', 'pdf' ) == "true":
		shutil.copy( pdf_tmp, pdf_out )
		print( "  |  | * PDF written to output folder!" )

	if config.get( 'Output', 'png' ) == "true":
		shutil.copy( png_tmp, png_out )
		print( "  |  | * PNG written to output folder!" )

	if config.get( 'Output', 'svg' ) == "true":
		shutil.copy( svg_tmp, svg_out )
		print( "  |  | * SVG written to output folder!" )

	if config.get( 'Output', 'ini' ) == "true":
		shutil.copy( cfg_tmp, cfg_out )
		print( "  |  | * INI written to output folder!" )

print( " -> All operations finished :3" )
if config.get( 'Behaviour', 'pause' ) == "true":
	os.system('pause')










#




























#
