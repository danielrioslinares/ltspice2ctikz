

import os, sys
import re
from math import atan,pi

import itertools

ROUND = 4
SCALE = [ 1/100, -1/100 ]
GRID = 16
LINESTYLE = { "" : "solid", "1" : "dashed", "2" : "dotted" , "3" : "dashdotted", "4" : "draw=none" }

def arange( start, stop, step ):
	result = [ start ]
	while result[-1] < stop:
		result.append( round( result[-1] + step, ROUND ) )
	return result

class Asc:

	def __init__( self, fpath, sym_lib = None ):
		# Sheet path
		self.fpath = fpath
		self.sym_lib = sym_lib

		# List of components
		self.wirs = []
		self.flgs = []
		self.syms = []
		self.txts = []
		self.lins = []
		self.recs = []
		self.ells = []
		self.arcs = []

		# Options
		self.ctikzset = [
			"logic ports = ieee",
			"bipoles/cuteswitch/thickness = 0.5",
			"monopoles/vee/arrow = latex, monopoles/vcc/arrow = latex",
			"cute inductors",
			"/tikz/circuitikz/bipoles/thickness=0.5",
			"inner sep = 1mm",
			"bipoles/resistor/height=0.24, bipoles/resistor/width=0.55",
			"bipoles/capacitor/height=0.45, bipoles/capacitor/width=0.17",
			"inductors/width=0.52",
			"bipoles/diode/height=0.36, bipoles/diode/width=0.36",
			"bipoles/thickness=0.9",
			"bipoles/crossing/size=0.24",
            "tripoles/thickness=1",
			]
		self.tikzset = [
			"triangle/.style = {fill = black, regular polygon, regular polygon sides = 3, inner sep = 0pt, minimum size = 5pt}",
			"square/.style = {fill = black, regular polygon, regular polygon sides = 4, minimum size = 5pt, inner sep = 0}",
			"myground/.style = rground",
		]
		self.packages = [
			"tikz",
			"circuitikz",
			"siunitx",
			"xcolor",
			"ifthen",
			"relsize"
			]
		self.tikzlibraries = [
			"shapes.geometric",
			"calc",
			]
		self.tikzpicture = [
			"line cap = miter",
			"scale = 0.75, every node/.style = {scale = 0.75}",
			"line width = 0.5",
			]

	def __repr__( self ):

		latex_code = ""

		## Header
		latex_code += r"\documentclass{standalone}" + "\n"
		for pkg in self.packages:
			latex_code += r"\usepackage{{{}}}".format( pkg ) + "\n"
		for opt in self.tikzlibraries:
			latex_code += r"\usetikzlibrary{{{}}}".format( opt ) + "\n"
		latex_code += r"\begin{document}" + "\n"
		latex_code += r"\ctikzset{" + "\n"
		for opt in self.ctikzset:
			latex_code += " {},".format( opt ) + "\n"
		latex_code += "}" + "\n"
		latex_code += r"\tikzset{" + "\n"
		for opt in self.tikzset:
			latex_code += " {},".format( opt ) + "\n"
		latex_code += "}" + "\n"
		latex_code += r"\begin{tikzpicture}[" + "\n"
		for opt in self.tikzpicture:
			latex_code += " {},".format( opt ) + "\n"
		latex_code += "]" + "\n"

		# Get shapes
		with open( self.fpath ) as file:

			# For each line
			for line in file:
				text = line.rstrip()
				row = text.split( " " )

				# Wires
				if row[0] == "WIRE":
					self.wirs.append( Wire( *row[1:] ) )

				# Symbol
				if row[0] == "SYMBOL":
					self.syms.append( Symbol( *row[2:] ) )
					self.syms[-1].sym_name = row[1]

				if row[0] == "SYMATTR":

					if row[1] == "InstName":
						self.syms[-1].instname = text[ len("SYMATTR InstName "): ]
					if row[1] == "SpiceModel":
						self.syms[-1].spicemodel = text[ len("SYMATTR SpiceModel "): ]
					if row[1] == "Value":
						self.syms[-1].value = text[ len("SYMATTR Value "): ]
					if row[1] == "Value2":
						self.syms[-1].value2 = text[ len("SYMATTR Value2 "): ]
					if row[1] == "SpiceLine":
						self.syms[-1].spiceline = text[ len("SYMATTR SpiceLine "): ]
					if row[1] == "SpiceLine2":
						self.syms[-1].spiceline2 = text[ len("SYMATTR SpiceLine2 "): ]

				# Text
				if row[0] == "TEXT":
					self.ells.append( Text( *row[1:5], " ".join(row[5:]) ) )

				# Flags
				if row[0] == "FLAG":
					self.flgs.append( Flag( *row[1:] ) )

				if row[0] == "IOPIN":
					self.flgs[-1].type = row[-1]

				# Rectangle
				if row[0] == "RECTANGLE":
					self.recs.append( Rectangle( *row[2:] ) )

				# Circle
				if row[0] == "CIRCLE":
					self.ells.append( Ellipse( *row[2:] ) )

				# Arcs
				if row[0] == "ARC":
					self.arcs.append( Arc( *row[2:] ) )

				# Lines
				if row[0] == "LINE":
					self.lins.append( Line( *row[2:] ) )

		########################################################################
		## Scale
		for item in self.wirs + self.flgs + self.syms + self.txts + self.lins + self.recs + self.ells + self.arcs:
			item.scale_and_offset( SCALE, [ 0, 0 ] )

		## Detect fields by default in the components
		for item in self.syms:
			item.detect_fields( self.sym_lib )

		## Jumpers
		jumpers = []

		# While a new jumper is detected
		new = True
		while new:
			# For all combinations...
			new = False
			for wir1,wir2 in itertools.combinations( self.wirs, 2 ):
				# ...get x,y crossing...
				x,y = wir1.crossing( wir2 )
				# ...if it exists and it's not shared...
				if x is not None and not wir1.share_bounds( wir2 ):
					# ...get the most horizontal line
					if wir1.y1 == wir1.y2 and wir1.x1 != wir1.x2:
						horizontal = wir1
						vertical = wir2
					elif wir2.y1 == wir2.y2 and wir2.x1 != wir2.x2:
						horizontal = wir2
						vertical = wir1
					else:
						continue
					# ...draw it! >:3
					latex_code += "\draw node [jump crossing] at ({},{}) {{}};".format( x, y ) + "\n"
					# ...split it! >:3
					self.wirs.append( Wire( min( horizontal.x1, horizontal.x2 ), y, x - abs(GRID * SCALE[0]), y ) )
					self.wirs.append( Wire( x + abs(GRID * SCALE[0]), y, max( horizontal.x1, horizontal.x2 ), y ) )
					self.wirs.append( Wire( x, min( vertical.y1, vertical.y2 ), x, y - abs(GRID * SCALE[1]) ) )
					self.wirs.append( Wire( x, max( vertical.y1, vertical.y2 ), x, y + abs(GRID * SCALE[1]) ) )
					# ...remove the old wires
					self.wirs.remove( horizontal )
					self.wirs.remove( vertical )
					# ...add a phantom symbol
					jumpers.append( Symbol( x, y ) )
					jumpers[-1].x_t = [ x - abs(GRID * SCALE[0]), x + abs(GRID * SCALE[0]), x, x ]
					jumpers[-1].y_t = [ y, y, y + abs(GRID * SCALE[1]), y - abs(GRID * SCALE[1]) ]
					jumpers[-1].x_t = [ round( x, ROUND ) for x in jumpers[-1].x_t ]
					jumpers[-1].y_t = [ round( y, ROUND ) for y in jumpers[-1].y_t ]
					# New jumper was added (start all over again)
					new = True
					break

		# Delete 0-length wires
		for wir in reversed(self.wirs):
			if wir.x1 == wir.x2 and wir.y1 == wir.y2:
				self.wirs.remove( wir )

		## Get nodes with multiple intersections
		nodes = []

		# First add all the symbols' terminals
		for sym in self.syms + jumpers:
			sym.detect_terminals()
			if len(sym.x_t) == len(sym.y_t):
				for x,y in zip( sym.x_t, sym.y_t ):
					new = True
					for node in nodes:
						if node[0] == x and node[1] == y:
							node[2] += 1
							new = False
					if new:
						nodes.append( [x, y, 1] )

		# Now add the wires' terminals
		for wir in self.wirs:
			for x,y in [ ( wir.x1, wir.y1 ), ( wir.x2, wir.y2 ) ]:
				new = True
				for node in nodes:
					if node[0] == x and node[1] == y:
						node[2] += 1
						new = False
				if new:
					nodes.append( [x, y, 1] )

		# Finally, print it
		for node in nodes:
			x,y = node[0],node[1]
			times = node[2]
			if times >= 3:
				latex_code += "\draw node [circ] at ({:.2f},{:.2f}) {{}};".format( x, y ) + "\n"

		## Draw polylines
		polywirs = []

		while len( self.wirs ) > 0:
			polywirs.append( [] )
			polywirs[-1].append( ( round( self.wirs[-1].x1, ROUND ), round( self.wirs[-1].y1, ROUND ) ) )
			polywirs[-1].append( ( round( self.wirs[-1].x2, ROUND ), round( self.wirs[-1].y2, ROUND ) ) )
			new = True
			while new:
				new = False
				for wir in self.wirs[:-1]:
					if wir.x1 == polywirs[-1][0][0] and wir.y1 == polywirs[-1][0][1]:
						polywirs[-1].insert( 0, ( round( wir.x2, ROUND ), round( wir.y2, ROUND ) ) )
						self.wirs.remove( wir )
						new = True
						break
					elif wir.x2 == polywirs[-1][0][0] and wir.y2 == polywirs[-1][0][1]:
						polywirs[-1].insert( 0, ( round( wir.x1, ROUND ), round( wir.y1, ROUND ) ) )
						self.wirs.remove( wir )
						new = True
						break
					elif wir.x1 == polywirs[-1][-1][0] and wir.y1 == polywirs[-1][-1][1]:
						polywirs[-1].append( ( round( wir.x2, ROUND ), round( wir.y2, ROUND ) ) )
						self.wirs.remove( wir )
						new = True
						break
					elif wir.x2 == polywirs[-1][-1][0] and wir.y2 == polywirs[-1][-1][1]:
						polywirs[-1].append( ( round( wir.x1, ROUND ), round( wir.y1, ROUND ) ) )
						self.wirs.remove( wir )
						new = True
						break
				if len( self.wirs ) == 0:
					new = False

			# Delete the wire
			self.wirs.remove( self.wirs[-1] )

		# Draw the polywires
		for polywir in polywirs:
			str = "\draw "
			for x,y in polywir:
				str += "({},{}) to [short] ".format( x, y )
			str = str[:-12]
			str += ";"
			latex_code += str + "\n"

		# Print the rest
		for item in self.wirs + self.syms + self.txts + self.lins + self.recs + self.ells + self.arcs + self.flgs:
			latex_code += item.__repr__() + "\n"

		## Footer
		latex_code += "\end{tikzpicture}" + "\n"
		latex_code += "\end{document}" + "\n"

		return latex_code


class Wire:

	def __init__( self, x1, y1, x2, y2 ):
		self.x1 = round( float( x1 ), ROUND )
		self.x2 = round( float( x2 ), ROUND )
		self.y1 = round( float( y1 ), ROUND )
		self.y2 = round( float( y2 ), ROUND )

	def scale_and_offset( self, scale, offset ):
		self.x1 = round( ( self.x1 - offset[0] ) * scale[0], ROUND )
		self.y1 = round( ( self.y1 - offset[1] ) * scale[1], ROUND )
		self.x2 = round( ( self.x2 - offset[0] ) * scale[0], ROUND )
		self.y2 = round( ( self.y2 - offset[1] ) * scale[1], ROUND )

	def __repr__( self ):
		return "\draw ({},{}) to [short] ({},{});".format( round( self.x1, ROUND ), round( self.y1, ROUND ), round( self.x2, ROUND ), round( self.y2, ROUND ) )

	def crossing( self, other ):
		# Step
		dx = abs( GRID * SCALE[0] )
		dy = abs( GRID * SCALE[1] )

		# Convert a line into a set of (x,y) nodes...
		# ...in case it's an horizontal line
		if self.y1 == self.y2:
			x1,x2 = min( self.x1, self.x2 ), max( self.x1, self.x2 )
			x_l = arange( x1, x2, dx )
			self_line = [ (x,self.y1) for x in x_l ]
		if other.y1 == other.y2:
			x1,x2 = min( other.x1, other.x2 ), max( other.x1, other.x2 )
			x_l = arange( x1, x2, dx )
			other_line = [ (x,other.y1) for x in x_l ]
		# ...in case it's a vertical line
		if self.x1 == self.x2:
			y1,y2 = min( self.y1, self.y2 ), max( self.y1, self.y2 )
			y_l = arange( y1, y2, dy )
			self_line = [ (self.x1,y) for y in y_l ]
		if other.x1 == other.x2:
			y1,y2 = min( other.y1, other.y2 ), max( other.y1, other.y2 )
			y_l = arange( y1, y2, dy )
			other_line = [ (other.x1,y) for y in y_l ]

		# If other_line or self_line are not either vertical nor horizontal...
		if self_line is None or other_line is None:
			return None,None

		# Check if a single (x,y) tuple of one line is at the other
		for self_x,self_y in self_line:
			for other_x,other_y in other_line:
				if self_x == other_x and self_y == other_y:
					return round(self_x, ROUND), round(self_y, ROUND)

		# No intersection found
		return None,None

	def share_bounds( self, other ):
		if self.x1 == other.x1 and self.y1 == other.y1:
			return True
		if self.x1 == other.x2 and self.y1 == other.y2:
			return True
		if self.x2 == other.x2 and self.y2 == other.y2:
			return True
		if self.x2 == other.x1 and self.y2 == other.y1:
			return True
		return False

class Line(Wire):

	def __init__( self, x1, y1, x2, y2, linestyle = "" ):
		super().__init__( x1, y1, x2, y2 )
		self.lst = LINESTYLE[linestyle]

	def __repr__( self ):
		return "\draw [{}] ({},{}) to [short] ({},{});".format( self.lst, self.x1, self.y1, self.x2, self.y2 )

def instname_to_name( instname ):
	if instname[0] + instname[1] == "%s":
		return ""
	else:
		return "${}_{{{}}}$".format( instname[0], instname[1:] ) if instname[0] != "$" else instname

class Flag:

	def __init__( self, x, y, label, type = "net" ):
		self.x = float( x )
		self.y = float( y )
		self.label = label
		self.type = type

	def scale_and_offset( self, scale, offset ):
		self.x = round( ( self.x - offset[0] ) * scale[0], ROUND )
		self.y = round( ( self.y - offset[1] ) * scale[1], ROUND )

	def __repr__( self ):
		name = "${}_{{{}}}$".format( self.label[0], self.label[1:] ) if self.label[0] != "$" else self.label
		if self.label == "0":
			return r"\draw ({:.2f},{:.2f}) node [tground] {{ }};".format( self.x, self.y )
		if self.label == "COM":
			return r"\draw ({:.2f},{:.2f}) node [tlground] {{ }};".format( self.x, self.y )
		if self.type == "net":
			return r"\draw ({:.2f},{:.2f}) node [vcc] {{ {} }};".format( self.x, self.y, name )
		if self.type == "In":
			return r"\draw ({:.2f},{:.2f}) node [ocirc] {{}} node [left, inner sep = 1mm] {{ {} }};".format( self.x, self.y, name )
		if self.type == "Out":
			return r"\draw ({:.2f},{:.2f}) node [ocirc] {{}} node [right, inner sep = 2mm] {{ {} }};".format( self.x, self.y, name )
		if self.type == "BiDir":
			return r"\draw ({:.2f},{:.2f}) node [ocirc] {{}} node [above, inner sep = 2mm] {{ {} }};".format( self.x, self.y, name )

class Symbol:

	def __init__( self, x, y, rotate = "R0", instname = "", spicemodel = "", value = "", value2 = "", spiceline = "", spiceline2 = "", sym_name = "" ):
		self.x = float( x )
		self.y = float( y )
		self.x_t = [] # Terminals (x)
		self.y_t = [] # Terminals (y)
		self.sym_name = sym_name
		self.rotate = -int( rotate[1:] )
		self.mirror = ( rotate[0] == "M" )
		self.instname = instname
		self.spicemodel = spicemodel
		self.value = value
		self.value2 = value2
		self.spiceline = spiceline
		self.spiceline2 = spiceline2

	def scale_and_offset( self, scale, offset ):
		self.x = round( ( self.x - offset[0] ) * scale[0], ROUND )
		self.y = round( ( self.y - offset[1] ) * scale[1], ROUND )

	def detect_fields( self, sym_lib = None ):
		if sym_lib is not None:
			sym_path = os.path.join( sym_lib, self.sym_name + ".asy" )
			if os.path.isfile( sym_path ):
				with open( sym_path ) as file:
					for line in file:
						text = line.rstrip()
						row = text.split( " " )
						if row[0] == "SYMATTR":
							if row[1] == "InstName" and self.instname == "":
								self.instname = text[ len("SYMATTR InstName "): ]
							if row[1] == "SpiceModel" and self.spicemodel == "":
								self.spicemodel = text[ len("SYMATTR SpiceModel "): ]
							if row[1] == "Value" and self.value == "":
								self.value = text[ len("SYMATTR Value "): ]
							if row[1] == "Value2" and self.value2 == "":
								self.value2 = text[ len("SYMATTR Value2 "): ]
							if row[1] == "SpiceLine" and self.spiceline == "":
								self.spiceline = text[ len("SYMATTR SpiceLine "): ]
							if row[1] == "SpiceLine2" and self.spiceline2 == "":
								self.spiceline2 = text[ len("SYMATTR SpiceLine2 "): ]

	def detect_terminals( self ):
		# TikZ lines on LTSPICE
		string = self.spicemodel + self.value + self.value2 + self.spiceline + self.spiceline2

		# Rotation and mirroring
		if self.mirror:
			if self.rotate == 0: # WORKING
				string = string.replace( "%xm", str( "-1" ) )
				string = string.replace( "%ym", str( "1" ) )
				rotate = self.rotate
				xsign,ysign = "-","+"
				dx_i = 0
				dy_i = 0
			elif self.rotate == -90:
				string = string.replace( "%xm", str( "-1" ) )
				string = string.replace( "%ym", str( "1" ) )
				rotate = -270
				xsign,ysign = "+","-"
				dx_i = 3
				dy_i = 3
			elif self.rotate == -180: # WORKING
				string = string.replace( "%xm", str( "-1" ) )
				string = string.replace( "%ym", str( "1" ) )
				rotate = self.rotate
				xsign,ysign = "-","+"
				dx_i = 2
				dy_i = 2
			elif self.rotate == -270:
				string = string.replace( "%xm", str( "-1" ) )
				string = string.replace( "%ym", str( "1" ) )
				rotate = -90
				xsign,ysign = "+","-"
				dx_i = 1
				dy_i = 1
		else:
			string = string.replace( "%xm", str( "1" ) )
			string = string.replace( "%ym", str( "1" ) )
			rotate = self.rotate
			xsign,ysign = "+","+"
			dx_i = self.rotate // -90
			dy_i = self.rotate // -90

		# xy field
		for xyi,xyf in zip( reversed( [xyi for xyi in re.finditer( "xy%", string )] ), reversed( [xyf for xyf in re.finditer( "%xy", string )] ) ):
			substring = string[xyi.start():xyf.end()][3:-3]
			old_x,old_y = substring.split( "," )
			if dx_i == 0: x =  old_x
			elif dx_i == 1: x =  old_y
			elif dx_i == 2: x = "-" +  old_x
			elif dx_i == 3: x = "-" +  old_y
			if dy_i == 0: y = old_y
			elif dy_i == 1: y = "-" + old_x
			elif dy_i == 2: y = "-" +  old_y
			elif dy_i == 3: y =  old_x
			x = eval( str( self.x ) + xsign + x )
			y = eval( str( self.y ) + ysign + y )
			self.x_t.append( round( x, ROUND ) )
			self.y_t.append( round( y, ROUND ) )

		# x field as function of the rotation
		for xi,xf in zip( reversed( [xi for xi in re.finditer( "x%", string )] ), reversed( [xf for xf in re.finditer( "%x", string )] ) ):
			substring = string[xi.start():xf.end()]
			x = eval( str( self.x ) + xsign + substring.split("%")[1:-1][dx_i] )
			self.x_t.append( round( x, ROUND ) )

		# y field as function of the rotation
		for yi,yf in zip( reversed( [yi for yi in re.finditer( "y%", string )] ), reversed( [yf for yf in re.finditer( "%y", string )] ) ):
			substring = string[yi.start():yf.end()]
			y = eval( str( self.y ) + ysign + substring.split("%")[1:-1][dy_i] )
			self.y_t.append( round( y, ROUND ) )

	def __repr__( self ):
		# TikZ lines on LTSPICE
		string = self.spicemodel + self.value + self.value2 + self.spiceline + self.spiceline2

		# Rotation and mirroring
		if self.mirror:
			if self.rotate == 0: # WORKING
				string = string.replace( "%xm", str( "-1" ) )
				string = string.replace( "%ym", str( "1" ) )
				rotate = self.rotate
				xsign,ysign = "-","+"
				dx_i = 0
				dy_i = 0
			elif self.rotate == -90:
				string = string.replace( "%xm", str( "-1" ) )
				string = string.replace( "%ym", str( "1" ) )
				rotate = -270
				xsign,ysign = "+","-"
				dx_i = 3
				dy_i = 3
			elif self.rotate == -180: # WORKING
				string = string.replace( "%xm", str( "-1" ) )
				string = string.replace( "%ym", str( "1" ) )
				rotate = self.rotate
				xsign,ysign = "-","+"
				dx_i = 2
				dy_i = 2
			elif self.rotate == -270:
				string = string.replace( "%xm", str( "-1" ) )
				string = string.replace( "%ym", str( "1" ) )
				rotate = -90
				xsign,ysign = "+","-"
				dx_i = 1
				dy_i = 1
		else:
			string = string.replace( "%xm", str( "1" ) )
			string = string.replace( "%ym", str( "1" ) )
			rotate = self.rotate
			xsign,ysign = "+","+"
			dx_i = self.rotate // -90
			dy_i = self.rotate // -90

		string = string.replace( "%r", str( rotate ) )
		string = string.replace( "%m", "1" if self.mirror else "0" )

		# Name
		name = instname_to_name( self.instname )
		string = string.replace( "%nn", str( name ) )
		string = string.replace( "%n", r"\rotatebox{{{}}}{{{}}}".format( str( -rotate ), str( name ) ) )

		# TikZ identifier
		if self.instname[0] + self.instname[1] == "%s":
			string = string.replace( "%i", "tmp" )
		elif self.instname[0] == "$":
			string = string.replace( "%i", str( self.instname.replace( "$", "" ) ) )
		else:
			string = string.replace( "%i", str( self.instname ) )

		# Special characters
		string = string.replace( "%s", " " )
		string = string.replace( "%c", "," )
		string = string.replace( "%e", "=" )

		# xy field
		for xyi,xyf in zip( reversed( [xyi for xyi in re.finditer( "xy%", string )] ), reversed( [xyf for xyf in re.finditer( "%xy", string )] ) ):
			substring = string[xyi.start():xyf.end()][3:-3]
			old_x,old_y = substring.split( "," )
			if dx_i == 0: x =  old_x
			elif dx_i == 1: x =  old_y
			elif dx_i == 2: x = "-" +  old_x
			elif dx_i == 3: x = "-" +  old_y
			if dy_i == 0: y = old_y
			elif dy_i == 1: y = "-" + old_x
			elif dy_i == 2: y = "-" +  old_y
			elif dy_i == 3: y =  old_x
			x = eval( str( self.x ) + xsign + x )
			y = eval( str( self.y ) + ysign + y )
			string = string[:xyi.start()] + "{:.3f},{:.3f}".format( x, y ) + string[xyf.end():]

		# x field as function of the rotation
		for xi,xf in zip( reversed( [xi for xi in re.finditer( "x%", string )] ), reversed( [xf for xf in re.finditer( "%x", string )] ) ):
			substring = string[xi.start():xf.end()]
			string = string[:xi.start()] + "{:.3f}".format( eval( str( self.x ) + xsign + substring.split("%")[1:-1][dx_i] ) ) + string[xf.end():]

		# y field as function of the rotation
		for yi,yf in zip( reversed( [yi for yi in re.finditer( "y%", string )] ), reversed( [yf for yf in re.finditer( "%y", string )] ) ):
			substring = string[yi.start():yf.end()]
			string = string[:yi.start()] + "{:.3f}".format( eval( str( self.y ) + ysign + substring.split("%")[1:-1][dy_i] ) ) + string[yf.end():]

		return string

class Text:
	JUSTIFICATION = { "Left" : "right", "Right" : "left", "Top" : "below", "Bottom" : "above", "Center" : "" }
	FONTSIZE = [ 0.625, 1.0, 1.5, 2.0, 2.5, 3.5, 5.0, 7.0]
	def __init__( self, x, y, justification = "Left", fontsize_i = "3", txt = "" ):
		self.x = float( x )
		self.y = float( y )
		self.txt = txt
		self.jus = self.JUSTIFICATION[justification]
		self.fontscale = self.FONTSIZE[ int(fontsize_i) ] / 2.25

	def scale_and_offset( self, scale, offset ):
		self.x = round( ( self.x - offset[0] ) * scale[0], ROUND )
		self.y = round( ( self.y - offset[1] ) * scale[1], ROUND )

	def __repr__( self ):
		if self.txt[0] == ";":
			txt = self.txt[1:]
			if "$" not in txt: txt = txt.replace( "_", "\_" )
			return r"\draw ({},{}) node [{}, scale={:.3f}, inner sep = 0] {{ {} }};".format( self.x, self.y, self.jus, self.fontscale, txt )
		else:
			return self.txt[2:]

class Rectangle:

	def __init__( self, x1, y1, x2, y2, linestyle = "" ):
		self.x1 = float( x1 )
		self.x2 = float( x2 )
		self.y1 = float( y1 )
		self.y2 = float( y2 )
		self.lst = LINESTYLE[linestyle]

	def scale_and_offset( self, scale, offset ):
		self.x1 = round( ( self.x1 - offset[0] ) * scale[0], ROUND )
		self.x2 = round( ( self.x2 - offset[0] ) * scale[0], ROUND )
		self.y1 = round( ( self.y1 - offset[1] ) * scale[1], ROUND )
		self.y2 = round( ( self.y2 - offset[1] ) * scale[1], ROUND )

	def __repr__( self ):
		return "\draw [{}] ({},{}) rectangle ({},{});".format( self.lst, self.x1, self.y1, self.x2, self.y2 )

class Ellipse(Rectangle):

	def __init__( self, x1, y1, x2, y2, linestyle = "" ):
		super().__init__( x1, y1, x2, y2, linestyle )

	def __repr__( self ):
		rx = round( (max(self.x1,self.x2)-min(self.x1,self.x2)) / 2, ROUND )
		ry = round( (max(self.y1,self.y2)-min(self.y1,self.y2)) / 2, ROUND )
		return "\draw [{}] ({},{}) ellipse ({} and {});".format( self.lst, min(self.x1,self.x2) + rx, min(self.y1,self.y2) + ry, rx, ry )

#TODO
class Arc:

	def __init__( self, x1, y1, x2, y2, x3, y3, x4, y4, linestyle = "solid" ):
		self.x1 = float( x1 )
		self.x2 = float( x2 )
		self.y1 = float( y1 )
		self.y2 = float( y2 )
		self.x3 = float( x3 )
		self.x4 = float( x4 )
		self.y3 = float( y3 )
		self.y4 = float( y4 )
		self.lst = linestyle

	def scale_and_offset( self, scale, offset ):
		self.x1 = round( ( self.x1 - offset[0] ) * scale[0], ROUND )
		self.x2 = round( ( self.x2 - offset[0] ) * scale[0], ROUND )
		self.y1 = round( ( self.y1 - offset[1] ) * scale[1], ROUND )
		self.y2 = round( ( self.y2 - offset[1] ) * scale[1], ROUND )
		self.x3 = round( ( self.x3 - offset[0] ) * scale[0], ROUND )
		self.x4 = round( ( self.x4 - offset[0] ) * scale[0], ROUND )
		self.y3 = round( ( self.y3 - offset[1] ) * scale[1], ROUND )
		self.y4 = round( ( self.y4 - offset[1] ) * scale[1], ROUND )

	def __repr__( self ):
		rx = round( (max(self.x1,self.x2)-min(self.x1,self.x2)) / 2, ROUND )
		ry = round( (max(self.y1,self.y2)-min(self.y1,self.y2)) / 2, ROUND )
		cx = min(self.x1,self.x2) + rx
		cy = min(self.y1,self.y2) + ry
		ai = atan( ( self.y3 - cy ) / ( self.x3 - cx ) ) * 180 / pi
		af = atan( ( self.y4 - cy ) / ( self.x4 - cx ) ) * 180 / pi

		return "\draw [{}] ({:.3f},{:.3f}) ellipse ({:.3f} and {:.3f});".format( self.lst, cx, cy, rx, ry )
		return "\draw ({},{}) arc ( {}:{}:{} and {} );".format( self.x4, self.y4, -ai, af, rx, ry )

		return "\draw ( {},{} and {}) arc ({},{} and {});".format( self.x3, self.y3, rx, self.x4, self.y4, ry )























#
