

import ltspice2ctikz as l2c

import sys, os, shutil
import subprocess
import time

import configparser

# Check if the application is a frozen exe or not
if getattr(sys, 'frozen', False):
    application_path = os.path.dirname( sys.executable )
elif __file__:
    application_path = os.path.dirname( __file__ )

config_file = os.path.join(application_path, "config.ini")
config = configparser.ConfigParser()
config.read_file( open( config_file, 'r', encoding='utf-8' ) )

TEMPORAL_FOLDER = config.get( 'Settings', 'TEMPORAL_FOLDER' )
PDF2SVG = config.get( 'Settings', 'PDF2SVG' )
PDFLATEX = config.get( 'Settings', 'PDFLATEX' )
SYM_LIB = config.get( 'Settings', 'SYM_LIB' )



# Input files
for f_input in sys.argv[1:]:
	print( "File {}...".format( f_input ) )
	if os.path.isfile( f_input ):
		print( " -> Schematic found!" )
	else:
		print(" -> FATAL ERROR: schematic not found!")
		sys.exit(-1)

	# Get schematic
	s = l2c.Asc( f_input, sym_lib = SYM_LIB )

	# Convert to tex code
	tex = s.__repr__()
	print( " -> Schematic converted to TeX code" )

	print( " -> Deleting old temporal files..." )
	for tmp_file in [ "tmp.pdf", "tmp.svg" ]:
		try: os.remove( os.path.join( TEMPORAL_FOLDER, tmp_file ) )
		except: pass

	# Run the TeX code in the temporal folder
	tex_tmp = os.path.join( TEMPORAL_FOLDER, "tmp.tex" )
	tex_out = os.path.join( f_input[:-3] + "tex" )
	print( tex, file = open( tex_tmp, 'w' ) )
	print( " -> TeX code written to temporal folder!" )
	#os.system( "{} {} -output-directory=\"{}\"".format( PDFLATEX, tex_tmp, TEMPORAL_FOLDER ) )
	subprocess.call( "{} {} -output-directory=\"{}\"".format( PDFLATEX, tex_tmp, TEMPORAL_FOLDER ), stdout=subprocess.DEVNULL )
	print( " -> PDF written to temporal folder!" )
	pdf_tmp = os.path.join( TEMPORAL_FOLDER, "tmp.pdf" )
	pdf_out = os.path.join( f_input[:-3] + "pdf" )
	svg_tmp = os.path.join( TEMPORAL_FOLDER, "tmp.svg" )
	svg_out = os.path.join( f_input[:-3] + "svg" )
	#os.system( "{} {} {} {}".format( PDF2SVG, pdf_tmp, svg_tmp, "1" ) )
	subprocess.call( "{} {} {} {}".format( PDF2SVG, pdf_tmp, svg_tmp, "1" ), stdout=subprocess.DEVNULL )
	print( " -> PDF converted to SVG" )

	# Move the .tex, .pdf and .svg to the output folder
	shutil.copy( tex_tmp, tex_out )
	print( " -> TeX written to output folder!" )

	shutil.copy( pdf_tmp, pdf_out )
	print( " -> PDF written to output folder!" )

	shutil.copy( svg_tmp, svg_out )
	print( " -> SVG written to output folder!" )













#




























#
